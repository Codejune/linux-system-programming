#include "ssu_mntr.h"

void files(char *path, listPointer parent);
void insertFirst(listPointer *first, listPointer new_node);

listPointer check;
int log_fd;
char *trash;
pid_t d_pid;

int ssu_daemon_init(void)
{
	pid_t pid;
	int fd, maxfd;
	char *log_filename = "log.txt";
	check = NULL;
	
	if((pid = fork()) < 0)
	{
		fprintf(stderr, "fork error\n");
		exit(1);
	}
	else if(pid != 0)
	{
		exit(0);
	}

	d_pid = getpid();
	setsid();
	signal(SIGTTIN, SIG_IGN);
	signal(SIGTTOU, SIG_IGN);
	signal(SIGTSTP, SIG_IGN);
	maxfd = getdtablesize();

	for(fd = 0; fd < maxfd; fd++)
		close(fd);

	umask(0);
	//chdir("");

	fd = open("/dev/null", O_RDWR);
	dup(0);
	dup(0);

	trash = malloc(sizeof(char) * PATHMAX);
	getcwd(trash, PATHMAX);

	Tree_setting("check", NULL);// tree traveling

	while(1)
	{
		if((log_fd = open(log_filename, O_WRONLY | O_CREAT, 0666)) < 0)
		{
			fprintf(stderr, "fopen error for %s\n", log_filename);
			exit(1);
		}

		files("check", check);//compare tree with before
		sleep(10);


		close(log_fd);
	}
}

listPointer Tree_setting(char *path, listPointer parent)
{
	struct dirent *dirp;
	DIR *dp;
	char *path_name;

	if(check == NULL || parent == NULL)
	{
		listPointer lp;
		information info;

		strcpy(info.name, "check");
		
		if(stat(info.name, &(info.statbuf)) == -1)
		{
			fprintf(stderr, "test stat error\n");//
			exit(1);
		}

		lp = makeNode(&info);//make node

		insertFirst(&check, lp);//insert node
		parent = lp; 
	}

	chdir(path);

	path_name = malloc(sizeof(char) * PATHMAX);
	getcwd(path_name, PATHMAX);

	if((dp = opendir(path_name)) == NULL)
	{
		fprintf(stderr, "opendir error\n");//
		exit(1);
	}
	
	while((dirp = readdir(dp)) != NULL)
	{
		information info;
		listPointer lp;
		
		if(strcmp(dirp->d_name, ".") && strcmp(dirp->d_name, ".."))
		{
			strcpy(info.name, dirp->d_name);
		
			if(stat(info.name, &(info.statbuf)) == -1)
			{
				fprintf(stderr, "stat error\n");//
				exit(1);
			}

			lp = makeNode(&info);

			insert_childNode(parent, lp);//insert child node 

			if((info.statbuf.st_mode & S_IFMT) == S_IFREG)
			{
				//printf("%s\t%ld\n", info.name, info.statbuf.st_size);
			}else
			{
				//printf("file %s\n", info.name);
				Tree_setting(info.name, lp);//recursive
			}
		}
	}

	free(path_name);
	closedir(dp);
	chdir("..");
	
	return parent;
}

void files(char *path, listPointer parent)
{
	struct dirent *dirp;
	DIR *dp;
	char *path_name;
	chdir(path);

	path_name = (char *)malloc(sizeof(char)*PATHMAX);

	getcwd(path_name, PATHMAX);
	//printf("%s\n", path_name);//

	if((dp = opendir(path_name)) == NULL)
	{
		fprintf(stderr, "opendir error\n");//
		exit(1);
	}

	while((dirp = readdir(dp)) != NULL)
	{
		information info;
		listPointer temp = parent->child;
	
		if(strcmp(dirp->d_name, ".") && strcmp(dirp->d_name, ".."))
		{
			strcpy(info.name, dirp->d_name);
			
			if(stat(info.name, &(info.statbuf)) == -1)
			{
				fprintf(stderr, "stat error\n");//
				exit(1);
			}

			if(is_childNode(info.name, parent))	
			{
				/*update*/

				for(;(strcmp(info.name, temp->info.name) != 0) && temp->right != temp;)
				{
					temp = temp->right;
				}

				if(temp->info.statbuf.st_mtime != info.statbuf.st_mtime)
				{
					temp->info.statbuf = info.statbuf;
					lseek(log_fd, 0, SEEK_END);
					write_log(temp->info.name, time(0),"Modify");
				}
			}
			else//create new file node
			{
				listPointer lp;

				lp = makeNode(&info);
				insert_childNode(parent, lp); //add new child node
				lseek(log_fd, 0, SEEK_END);
				write_log(lp->info.name, time(0), "Create");
			}

			if((info.statbuf.st_mode & S_IFMT) == S_IFREG)
			{
				printf("%s\t%ld\n", info.name, info.statbuf.st_size);
			}else
			{
				//printf("file %s\n", info.name);
				files(info.name, temp);//recursive
			}

		}
	}

	file_list(parent);//delete child node and add delete log
	
	closedir(dp);
	free(path_name);
	chdir("..");
}

void insertFirst(listPointer *first, listPointer new_node)
{
	*first = new_node;
}  

listPointer makeNode(information *info)
{
	listPointer root = (listPointer)malloc(sizeof(list));

	if(root == NULL)
	{
		fprintf(stderr, "memory error\n");
		exit(1);
	}

	strcpy(root->info.name, info->name);
	root->info.statbuf = info->statbuf;
	root->parent = NULL;
	root->child = NULL;
	root->right = root;
	root->left = root;


	return root;
}

void insert_childNode(listPointer parent, listPointer child)
{
	child->parent = parent;

	if(parent->child)//parent has child
	{
		listPointer temp = parent->child;

		if(strcmp(child->info.name, temp->info.name) < 0)//new child is ahead
		{
			child->right = temp;
			temp->left = child;
			parent->child = child;
		}
		else
		{
			/*new child is between*/

			for(;((strcmp(child->info.name, temp->info.name) > 0) && temp->right != temp);)
			{
				temp = temp->right;
			}
			
			if(strcmp(child->info.name, temp->info.name) < 0)
				temp = temp->left;

			if(temp->right != temp)
			{
				child->right = temp->right;
				child->right->left = child;
			}	

			temp->right = child;
			child->left = temp;
		}
	}else// no child
	{
		parent->child = child;
	}

}

void delete_childNode(listPointer parent, listPointer child)
{
	if(parent->child == child)//delete node is ahead
	{
		parent->child = child->right;
		parent->child->left = NULL;
	}else//delete node is between
	{
		child->left->right = child->right;
		child->right->left = child->left;

		if(child->right == child)
			child->left->right = child->left;
	}

	write_log(child->info.name, time(0),"Delete");//written in the current time
}

void file_list(listPointer parent) //compare  previous nodes and current files
{
	listPointer temp = parent->child;
	struct dirent **namelist;
	int n, i = 0;

	n = scandir(".", &namelist, NULL, alphasort);//sort alpahbet

	if(n < 0)
		perror("scandir");
	else
	{
		while(i < n)
		{
			if(strcmp(namelist[i]->d_name, ".") && strcmp(namelist[i]->d_name, ".."))
			{
				if(strcmp(temp->info.name, namelist[i]->d_name) != 0)
				{
					delete_childNode(parent, temp);//delete node
					i--;//compare the following with the same file 
				}

				temp = temp->right;
			}

			free(namelist[i]);
			i++;
		}
		free(namelist);
	}
}

int is_childNode(char *filename, listPointer parent)
{
	listPointer temp = parent->child;	
	
	for(;(strcmp(temp->info.name, filename) != 0);)
	{
		if(temp->right == temp)
		{
			return FALSE;//no child node
		}

		temp = temp->right;
	}

	return TRUE;	
}

/*void print_childNode(listPointer parent) 
{
	listPointer temp = parent->child; 

	for(;temp->right != temp;temp = temp->right)
	{
		printf("temp %s\n", temp->info.name);
	}
		printf("temp %s\n", temp->info.name);
}*/

/*void move_trash(listPointer child)
{
	char *temp;
	char *tmp;
	char path[BUFFER_SIZE] = {0};
	char t[BUFFER_SIZE] = {0};
	struct tm* tm;
	int trash_fd;

	temp = malloc(sizeof(char) * PATHMAX);
	strcpy(temp, trash);
	strcat(temp, "/trash");//make trash path
	
	//access
	if(access(temp, F_OK) < 0)
	{
		char *tmp1;
		char *tmp2;

		tmp1 = malloc(sizeof(char) * PATHMAX);
		tmp2 = malloc(sizeof(char) * PATHMAX);
		strcpy(tmp1, temp);
		strcpy(tmp2, temp);
		
		mkdir(temp, 0777);

		strcat(tmp1, "/files");
		mkdir(tmp1, 0777);

		strcat(tmp2, "/info");
		mkdir(tmp2, 0777);

		free(tmp1);
		free(tmp2);

	}

	char info[BUFFER_SIZE] = "/info/";
	char name[BUFFER_SIZE];

	tmp = malloc(sizeof(char) * PATHMAX);
	strcpy(tmp, temp);
	//name_separation(child->info.name, name);
	strcat(info, name);
	strcat(tmp, info);//make info path

	//printf("tmp %s\n", tmp);
	if((trash_fd  = open(tmp, O_WRONLY | O_CREAT, 0666)) < 0)//open log file
	{
		fprintf(stderr, "open error\n");
		exit(1);
	}

	time_t clock = time(0);
	tm = localtime(&clock);
	realpath(child->info.name, path);
	sprintf(t, "[Trash info]\n%s\n%04d-%02d-%02d %02d:%02d:%02d\n", path, tm->tm_year+1900, tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec);
	write(trash_fd, t, sizeof(t));//write path in log
	free(tmp);

	char files[BUFFER_SIZE] = "/files/";
	tmp = malloc(sizeof(char) * PATHMAX);
	strcpy(tmp, temp);
	strcat(files, child->info.name);
	strcat(tmp, files);//make

	if(rename(path, tmp) < 0)
	{
		fprintf(stderr, "rename error\n");
		exit(1);
	}

}*/

/*void name_separation(char *fullname, char *name)
{
	int i;
	for(i = 0; fullname[i] != '.'; i++)
	{
		name[i] = fullname[i];
	}

	name[i] = '\0';
}*/

void write_log(char *filename, time_t time, char *log)
{
	char t[BUFFER_SIZE] = {0};
	struct tm* tm;

	tm = localtime(&time);
	sprintf(t, "[%04d-%02d-%02d %02d:%02d:%02d][%s_%s]\n", tm->tm_year+1900, tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec, log, filename);
	lseek(log_fd, 0, SEEK_END);
	write(log_fd, t, sizeof(t));//write log	
}

