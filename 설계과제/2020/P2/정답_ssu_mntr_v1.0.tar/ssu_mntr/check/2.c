#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>

int main(void)
{
	exit(0);
}
