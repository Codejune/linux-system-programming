#ifndef	SSU_MNTR_H
#define	SSU_MNTR_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <malloc.h>
#include <time.h>
#include <errno.h>
#include <signal.h>
#include <dirent.h>
#include <sys/wait.h>

#define NAME_SIZE 100
#define BUFFER_SIZE 1024
#define FILE_MODE S_IWUSR | S_IRUSR | S_IWGRP | S_IRGRP | S_IWOTH | S_IROTH
#define PATHMAX 1024
#define FILE_NAME 1024
#define TRUE 1
#define FALSE 0
#define null 0

typedef struct information{
	char name[NAME_SIZE];
	struct stat statbuf;
}information;

typedef struct list* listPointer;
typedef struct list{
	listPointer parent;
	listPointer child;
	information info;
	listPointer right;
	listPointer left;
}list;

typedef struct trash_list* trash_listPointer;
typedef struct trash_list
{
	char original_name[NAME_SIZE];
	char original_path[NAME_SIZE];
	char trash_path[NAME_SIZE];
	char modify_time[NAME_SIZE];
	char delete_time[NAME_SIZE];

	trash_listPointer next;
	trash_listPointer previous;
}trash_list;

typedef struct same_trash_name* same_trash_list;
typedef struct same_trash_name
{
	trash_listPointer trash;
	same_trash_list next;

}same_trash_name;

typedef struct file_size
{
	char filename[NAME_SIZE];
	int size;
}file_size;

void help();

listPointer makeNode(information *info);

void insert_childNode(listPointer parent, listPointer child);

void delete_childNode(listPointer parent, listPointer child);

listPointer Tree_setting(char *path, listPointer parent);

void file_list(listPointer parent);

int is_childNode(char *filename, listPointer parent);

void print_childNode(listPointer parent);

void move_trash(listPointer child);

void write_log(char *filename, time_t time, char *log);

int name_separation(char* fullname, char *name, char *sep);

int remove_file(char *trash_path);

void delete_file();

void check_info_size();

int command_separation(char *line, int argc, char (*argv)[BUFFER_SIZE]);

trash_listPointer maketrashNode(char *original, char *original_path, char *trash_path, char *delete_time, char *modify_time);

void insert_trashNode(trash_listPointer new_node);

void insert_same_trash_name(same_trash_list *first, same_trash_list *last, same_trash_list new_node);

same_trash_name delete_trashNode(char *filename, int number);

void check_original(char *original_path);

void recover(char *filename, int flag_l);

double time_calculate(char *setting_date, char *setting_time);

void date_separation(char *setting_date, char *setting_time, int *date);

struct tm in_day_date(int yy, int mm, int dd, int h, int m, int s);

void ssu_signal_handler(int signo);

void signal_processing();

int size(char *filename, int number);

int sum_size(char *filename, int number, file_size f_S[], int *i);

void tree(listPointer check, int depth);

void tree_traveling(listPointer pparent, listPointer check, int depth);

void empty_function(listPointer check, int depth);
#endif
