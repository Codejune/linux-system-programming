#include "ssu_mntr.h"

int ssu_daemon_init(void);

trash_listPointer trash_first;
trash_listPointer trash_last;
int flag_i, flag_r, flag_d, flag_l;
char delete_filename[BUFFER_SIZE];
int trash_number;

int main(void)
{
	pid_t pid;
	pid_t cpid;
	//int length;
	int status;
	//struct list *temp;

	if((pid = fork()) < 0)
	{
		printf("fork error\n");
		exit(1);
	}
	else if(pid == 0)
	{
		if((cpid = ssu_daemon_init()) < 0)
		{
			fprintf(stderr, "ssu_daemon_init failed\n");
			exit(1);
		}
		printf("cpid = %d\n", cpid);
	}

	wait(&status);

	
	while(1)
	{
		char line[BUFFER_SIZE];//command
		char argv[6][BUFFER_SIZE] = {0};
		int argc = 0;
		int number;//-d option number
		int c;//option

		memset(argv, 0, sizeof(argv));

		//Tree_setting("check", check);

		printf("20201234>");
		fgets(line, sizeof(line), stdin);

		//printf("%s\n", line);
		argc = command_separation(line, argc, argv);//separate command
	
		int i = 0;
		//printf("argc : %d\n", argc);

		while(i < argc)
		{
			if(argv[i][0] == '-')
			{
				c = argv[i][1];

				switch(c)
				{
					case 'i':
						{
							flag_i = 1;
							break;
						}
					case 'r':
						{
							flag_r = 1;
							break;
						}
					case 'd':
						{
							if(argv[3] == 0)
								number = 1;
							else
								number = atoi(argv[3]);

							flag_d = 1;
							break;
						}
					case 'l':
						{
							flag_l = 1;
							break;
						}
				}
			}

			i++;
		}

		if(!strcmp(argv[0], "delete") || !strcmp(argv[0], "DELETE"))
		{
			double second = 0;
			strcpy(delete_filename, argv[1]);

			if(argv[2][0] != '\0'  && argv[3][0] != '\0')
			{
				second = time_calculate(argv[2], argv[3]);

				if(second < 0)
				{
					printf("second error\n");
					continue;
				}
			}
			else
			{
				signal_processing();
				continue;
			}

			signal(SIGALRM, ssu_signal_handler);
			alarm(second);
		}
		else if(!strcmp(argv[0], "size") || !strcmp(argv[0], "SIZE"))
		{
			size(argv[1], number);
			number = 1;
		}
		else if(!strcmp(argv[0], "recover") || !strcmp(argv[0], "RECOVER"))
		{
			recover(argv[1], flag_l);
		}
		else if(!strcmp(argv[0], "tree") || !strcmp(argv[0], "TREE"))
		{
			listPointer check = {0};

			check = Tree_setting("check", check);

			tree(check, 1);
			printf("\n");
		}
		else if(!strcmp(argv[0], "help") || !strcmp(argv[0], "HELP"))
		{
			help();
		}
		else if(!strcmp(argv[0], "exit") || !strcmp(argv[0], "EXIT"))
		{
			break;
		}
		else 
		{
			help();
		}
	}


	exit(0);
}

void help()
{
	printf("USAGE\n");
	printf("delete file\n · DELETE [FILENAME] [END_TIME] [OPTION] \n\n");
	printf("print file size\n  ·  SIZE [FILENAME] [OPTION] \n\n");
	printf("recover file\n · RECOVER [FILENAME] [OPTION] \n\n");
	printf("print file structure\n · TREE \n\n");
	printf("exit program\n");
	printf(" · EXIT\n\n");
	printf("print usage\n");
	printf(" · HELP \n\n");
}

int command_separation(char *line, int argc, char (*argv)[BUFFER_SIZE])
{
	for(int i = 0; i < (int)strlen(line) ; i++)
	{
		for(int j = 0;;j++, i++)
		{
			if (line[i] == ' ' || line[i] == '\n')
			{
				argc++;
				argv[argc][j] = '\0';
				break;
			}

			if(line[i] == '\n')
				break;

			argv[argc][j] = line[i];
		}
	}

	return argc;
}

void delete_file(char *name)
{
	 char *temp;
     char *tmp;
     char path[BUFFER_SIZE] = {0};
     char t[BUFFER_SIZE] = {0};
     struct tm* tm;
     int trash_fd;
 
     temp = malloc(sizeof(char) * PATHMAX);
     //strcpy(temp, trash);//getcwd
	 getcwd(temp, PATHMAX);
     strcat(temp, "/trash");//make trash path
    
	 //access
     if(access(temp, F_OK) < 0)
     {
		 /*make trash/file trash/info*/
         char *tmp1;
         char *tmp2;
 
         tmp1 = malloc(sizeof(char) * PATHMAX);
         tmp2 = malloc(sizeof(char) * PATHMAX);
         strcpy(tmp1, temp);
         strcpy(tmp2, temp);
 
         mkdir(temp, 0777);
 
         strcat(tmp1, "/files");
         mkdir(tmp1, 0777);

         strcat(tmp2, "/info");
         mkdir(tmp2, 0777);

         free(tmp1);
         free(tmp2);
     }
 
     char info[BUFFER_SIZE] = "/info/";
     char filename[BUFFER_SIZE];
 
     tmp = malloc(sizeof(char) * PATHMAX);
     strcpy(tmp, temp);
	 name_separation(name, filename, "/");
     strcat(info, filename);
	 strcat(tmp, info);//make info path

	 if((trash_fd  = open(tmp, O_WRONLY | O_CREAT, 0666)) < 0)
     {
         fprintf(stderr, "open error\n");
         exit(1);
     }


     realpath(name, path);//path

	 if(access(path, F_OK) < 0)
	 {
		 strcpy(path, name);
	 }

	 lseek(trash_fd, 0, SEEK_END);
	 sprintf(t, "[Trash info]\n%s\n",path);
     write(trash_fd, t, sizeof(t));
	 
	 time_t clock = time(0);
     tm = localtime(&clock);

	 /*info delete time*/
	 char delete_time[BUFFER_SIZE] = {0};
	 char time[BUFFER_SIZE] = {0};
	 //int length = 0;
	 sprintf(delete_time, "%04d-%02d-%02d %02d:%02d:%02d",tm->tm_year+1900, tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec);
	 sprintf(time, "D : %s\n", delete_time);
     write(trash_fd, time, sizeof(char) * strlen(time));

	 /*info modify time*/
	 struct stat statbuf;
	 stat(path, &statbuf);
     tm = localtime(&statbuf.st_mtime);

	 char modify_time[BUFFER_SIZE];
	 sprintf(modify_time, "%04d-%02d-%02d %02d:%02d:%02d",tm->tm_year+1900, tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec);
	 sprintf(time, "M : %s\n",modify_time);
     write(trash_fd, time, sizeof(char) * strlen(time));
	 
     free(tmp);
 
	 while(1)
	 {
		 /* set filename in trash*/

		 char files[BUFFER_SIZE] = "/files/";
		 char tmp_file[BUFFER_SIZE] = {0};
		 tmp = malloc(sizeof(char) * PATHMAX);
		 strcpy(tmp, temp);
		 //strcat(files, filename);//

		 sprintf(tmp_file, "%d", trash_number);
		 strcat(files, tmp_file);//
		 strcat(tmp, files);
		 trash_number++;

		 if(access(tmp, F_OK) != 0)
			 break;
	 }


	 //check trash/info

     if(rename(path, tmp) < 0)//move trash
     {
        fprintf(stderr, "there is no file\n");
		return;
     }


	 check_info_size();//check info 2kb

	trash_listPointer tl = maketrashNode(filename, path, tmp, delete_time, modify_time); //make trash node

	insert_trashNode(tl);
	free(tmp);
}

int remove_file(char *trash_path)//remove file recursively
{
	DIR *dir_ptr = NULL; 
	struct dirent *file = NULL; 
	struct stat buf; 
	char filename[1024]; 
	
	if((dir_ptr = opendir(trash_path)) == NULL) 
	{ 
		unlink(trash_path);
		return 0; 
	} 
	
	while((file = readdir(dir_ptr)) != NULL) 
	{
		if(strcmp(file->d_name, ".") == 0 || strcmp(file->d_name, "..") == 0) 
		{ 
			continue;
		} 
		
		sprintf(filename, "%s/%s", trash_path, file->d_name);
		
		if(stat(filename, &buf) == -1) 
		{ 
			continue;
		} 
		
		if(S_ISDIR(buf.st_mode)) 
		{ 
			remove_file(filename);

		} else  
		{ 
			unlink(filename);
		}
	} 
	
	closedir(dir_ptr); 
	rmdir(trash_path);

	return 0;
}

void check_info_size()
{
	char temp[BUFFER_SIZE] = {0}; 	
    char info[15] = "/trash/info";

	getcwd(temp, BUFFER_SIZE);
	strcat(temp, info);

	int sum = 0;
	struct stat statbuf;
	struct dirent *dentry;
	DIR *dirp;

	dirp = opendir(temp);

	while((dentry = readdir(dirp)) != NULL)//add file size
	{
		if(strcmp(dentry->d_name, ".") && strcmp(dentry->d_name, ".."))
		{
			char tmp[PATHMAX];

			strcpy(tmp, temp);
			strcat(tmp, "/");
			strcat(tmp, dentry->d_name);
			
			if(stat(tmp, &statbuf) == -1)
			{
				printf("stat error\n");
				exit(1);
			}
			
			sum += statbuf.st_size;

		}
	}

	if(sum > 2000)//change 2000
	{
		trash_listPointer tmp  = trash_first;
		char original_name[BUFFER_SIZE] = {0};

		strcpy(original_name, trash_first->original_name);

		//delete info
		strcat(temp, "/");
		strcat(temp, tmp->original_name);
		remove(temp);


		/*delete same file name*/
		while(1)
		{
			if(strcmp(tmp->original_name, original_name) == 0)
			{
				struct stat statbuf;

				if(stat(tmp->trash_path, &statbuf) == -1)
				{
					printf("stat error\n");
					exit(1);
				}
			
				remove_file(tmp->trash_path);

				if(tmp == trash_first)
					trash_first = tmp->next;
				else
				{
					tmp->previous->next = tmp->next;
					tmp->next->previous = tmp->previous;
				}

			}

			if(tmp->next == NULL)
				break;
			
			tmp = tmp->next; 
		}

	}
}

int name_separation(char *full, char *extract, char *sep)//get filename
{
	char *p;
	char temp[BUFFER_SIZE];
	int loc = 0;
	
	strcpy(temp, full);

	p = strtok(temp, sep);
	
	while(p != NULL)
	{
		loc = loc + strlen(p) + 1;
		strcpy(extract, p);
		p = strtok(NULL, sep);
	}

	return loc;
}

trash_listPointer maketrashNode(char *original, char *original_path, char *trash_path, char *delete_time, char *modify_time)
{
	trash_listPointer root = (trash_listPointer)malloc(sizeof(trash_list));
	//char tmp[BUFFER_SIZE];

	if(root == NULL)
	{
		fprintf(stderr, "memory error\n");
		exit(1);
	}

	strcpy(root->original_name, original);
	strcpy(root->original_path, original_path);
	strcpy(root->trash_path, trash_path);
	strcpy(root->delete_time, delete_time);
	strcpy(root->modify_time, modify_time);
	root->next = NULL;
	root->previous = NULL;

	return root;
}

void insert_trashNode(trash_listPointer new_node)
{
	if(trash_first)//trash node is already exist
	{
		new_node->previous = trash_last;
		trash_last->next = new_node;
		trash_last = new_node;
	}
	else
	{
		trash_first = new_node;
		trash_last = new_node;
	}
}

void insert_same_trash_name(same_trash_list *first, same_trash_list *last,same_trash_list new_node)
{
	if((*first)->trash)
	{
		(*last)->next = new_node;
		*last = new_node;
	}else
	{
		*first = new_node;
		*last = new_node;
	}
}

same_trash_name delete_trashNode(char *filename, int number)//delete trash node
{
	trash_listPointer tmp = trash_first;
	same_trash_name same_trash_tmp = {0};

	if(strcmp(tmp->original_name, filename) == 0 && number == 1)
	{
		same_trash_tmp.trash = tmp;
		
		if(tmp->next == NULL)	
		{
			trash_first = NULL;
		}
		else
		{
			trash_first = trash_first->next;
		}

		return same_trash_tmp;
	}
	else{
		if(strcmp(tmp->original_name, filename) == 0)
			number--;

		for(; number != 0;)
		{
			if(strcmp(tmp->next->original_name, filename) == 0)
				number--;

			tmp = tmp->next;
		}	

		same_trash_tmp.trash = tmp;
		tmp->previous->next = tmp->next;
	}			

	return same_trash_tmp;
}

void check_original(char *original_path)//check if file exists in original path
{
	int loc = 0;
	int i = 0;
	char original_name[BUFFER_SIZE] = {0};

	name_separation(original_path, original_name, "/");	
	loc = strlen(original_path)-strlen(original_name);

	while(access(original_path, F_OK) == 0)//find missing name
	{
		char change_name[BUFFER_SIZE] = {0};

		sprintf(change_name,"%d_", i);
		strcat(change_name, original_name);

		char *change = original_path + loc;
		strcpy(change, change_name);

		i++;
	}
}

void recover(char *filename, int flag_l)
{
	trash_listPointer tmp  = trash_first;
	same_trash_list same_trash_first = (same_trash_list)malloc(sizeof(same_trash_name));
	same_trash_list same_trash_last = (same_trash_list)malloc(sizeof(same_trash_list));
	int number = 1;
	int count = 0;

	memset(same_trash_first, 0, sizeof(same_trash_name));
	while(1)
	{
		if(strcmp(tmp->original_name, filename) == 0)//add same trash list
		{
			same_trash_list same_trash = (same_trash_list)malloc(sizeof(same_trash_name));
			same_trash->trash = tmp;
			same_trash->next = NULL;
		
			insert_same_trash_name(&same_trash_first, &same_trash_last, same_trash);

			count++;	
		}

		if(flag_l)
		{
			printf("%d.\t%s\t%s\n", number, tmp->original_name, tmp->delete_time);
		}

		if(tmp->next == NULL)
			break;
		tmp = tmp->next; 
		number++;
	}

	if(count)
	{
		int choose = 1;
		same_trash_list same_trash_tmp = same_trash_first;
		
		if(count == 1)//file is one 
		{
			char temp[BUFFER_SIZE] = {0};
			char tmp[BUFFER_SIZE] = {0};
			getcwd(temp, BUFFER_SIZE);
			char *info = "/trash/info/";
			
			name_separation(same_trash_first->trash->original_path, tmp, "/");
			strcat(temp, info);
			strcat(temp, tmp);
			unlink(temp);
			
			same_trash_name same_trash_temp = {0};
			same_trash_temp = delete_trashNode(same_trash_first->trash->original_name, choose);
			
			//check_original(same_trash_first->trash->original_path);
			check_original(same_trash_temp.trash->original_path);
			
			rename(same_trash_first->trash->trash_path, same_trash_first->trash->original_path);
		}
		else
		{
			int i = 1;

			for(;same_trash_tmp != NULL;)
			{
				printf("%d. %s\t%s\t%s\n", i, same_trash_tmp->trash->original_name, same_trash_tmp->trash->delete_time, same_trash_tmp->trash->modify_time);
				i++;
				same_trash_tmp = same_trash_tmp->next;
			}

			printf("Choose : ");
			scanf("%d", &choose);
			
			same_trash_name same_trash_temp = {0};
			same_trash_temp = delete_trashNode(same_trash_first->trash->original_name, choose);

			check_original(same_trash_temp.trash->original_path);
			rename(same_trash_temp.trash->trash_path, same_trash_temp.trash->original_path);
		}	
	}

}

double time_calculate(char *setting_date, char *setting_time)// calculate second
{
	double second = 0;
   // struct tm *tm;
	struct tm setting_tm;
	time_t clock = time(0);
	time_t setting_clock;
	int date[6] = {0};

	date_separation(setting_date, setting_time, date);

	setting_tm = in_day_date(date[0], date[1], date[2], date[3], date[4], date[5]);

	setting_clock = mktime(&setting_tm);//change tm->clock

	second = difftime(setting_clock, clock);

	return second;
}

void date_separation(char *setting_date, char *setting_time, int *date)
{
	char *p;
	char temp[BUFFER_SIZE];
	int i = 0;
	
	strcpy(temp, setting_date);

	p = strtok(temp, "-");

	while(p != NULL)
	{
		char tmp[BUFFER_SIZE];
		
		strcpy(tmp, p);
		date[i] = atoi(tmp);
		i++;

		p = strtok(NULL, "-");
	}


	strcpy(temp, setting_time);
	p = strtok(temp, ":");
	
	while(p != NULL)
	{
		char tmp[BUFFER_SIZE];
		
		strcpy(tmp, p);
		date[i] = atoi(tmp);
		i++;

		p = strtok(NULL, ":");
	}

}

struct tm in_day_date(int yy, int mm, int dd, int h, int m, int s)
{
	struct tm tm;
	tm.tm_year = yy - 1900;
	tm.tm_mon = mm - 1;
	tm.tm_mday = dd;
	tm.tm_hour = h;
	tm.tm_min = m;
	tm.tm_sec = s;
	tm.tm_isdst = 0;

	return tm;
}

void ssu_signal_handler(int signo)//alarm handler
{
	/*char answer;

	if(flag_i)//directory pass
	{
		struct stat statbuf;

		if(stat(delete_filename, &statbuf) == -1)
		{
			fprintf(stderr, "stat error\n");
			return;
		}

		if(!S_ISDIR(statbuf.st_mode))
			remove(delete_filename);//directory error

		flag_i = 0;
		return;
	}

	if(flag_r)
	{
		printf("Delete? [y/n] ");
		scanf("%c", &answer);

		if(answer == 'n' || answer == 'N')
		{
			flag_r = 0;
			return;
		}
	}

	delete_file(delete_filename);*/
	if(signo == SIGALRM)
		signal_processing();
}

void signal_processing()
{
	char answer;

	if(flag_i)//directory pass
	{
		struct stat statbuf;

		if(stat(delete_filename, &statbuf) == -1)
		{
			fprintf(stderr, "stat error\n");
			return;
		}

		if(!S_ISDIR(statbuf.st_mode))
			remove(delete_filename);//directory error

		flag_i = 0;
		return;
	}

	if(flag_r)
	{
		printf("Delete? [y/n] ");
		scanf("%c", &answer);

		if(answer == 'n' || answer == 'N')
		{
			flag_r = 0;
			return;
		}
	}

	delete_file(delete_filename);
}

int size(char *filename, int number)
{
	struct stat statbuf;
	int sum;
	int i = 0;

	file_size fs[BUFFER_SIZE] = {0};

	if(access(filename, F_OK) != 0)	
	{
		printf("There is no file or directory with the name %s\n", filename);
		return 0;
	}

	if(stat(filename, &statbuf) < 0)		
	{
		printf("stat error\n");
		return 0;
	}

	if(!S_ISDIR(statbuf.st_mode))
	{
		printf("%ld\t%s\n", statbuf.st_size, filename);
	}
	else
	{
		sum = sum_size(filename, number, fs, &i);
		printf("%d\t%s\n", sum, filename);
		strcpy(fs[i].filename, filename);
		fs[i].size = sum;
	}

	int j,k;

	/*sort alpha*/
	for(j = 0; j < i - 1; j++)
	{
		for(k = 0; k < i - j -1; k++)
		{
			if(strcmp(fs[k].filename, fs[k+1].filename) > 0)
			{
				file_size temp;

				temp = fs[k];
				fs[k] = fs[k+1];
				fs[k+1] = temp;
			}
		}
	}

	for(j = 0; j < i; j++)
		printf("%d\t%s\n", fs[j].size, fs[j].filename);


	return sum;
}

int sum_size(char *filename, int number, file_size fs[], int *i)
{
	int sum = 0;//sum of file size
	struct stat statbuf;
	struct dirent *dentry;
	DIR *dirp;
	char temp[PATHMAX];

	strcpy(temp, filename);

	dirp = opendir(temp);

	while((dentry = readdir(dirp)) != NULL)
	{
		if(strcmp(dentry->d_name, ".") && strcmp(dentry->d_name, ".."))
		{
			char tmp[PATHMAX];
			int dir_sum;

			strcpy(tmp, temp);
			strcat(tmp, "/");
			strcat(tmp, dentry->d_name);
			//printf("tmp : %s\n", tmp);
			if(stat(tmp, &statbuf) == -1)
			{
				printf("stat error\n");
				exit(1);
			}

			if(!S_ISDIR(statbuf.st_mode))
			{
				dir_sum = statbuf.st_size;
				sum += dir_sum;
			}
			else
			{
				int temp_number = number - 1;//next depth
		
				dir_sum = sum_size(tmp, temp_number, fs, i);
				sum += dir_sum;
			}

			if(number > 1)
			{
				//printf("%d\t%s\n", dir_sum, tmp);//change struct and sort
				strcpy(fs[*i].filename, tmp);
				fs[*i].size = dir_sum;
				*i += 1;
			}

		}
	}

	return sum;
}

void tree(listPointer check, int depth)
{
	printf("━%s", check->info.name);
	tree_traveling(check, check->child, depth++);
}

void tree_traveling(listPointer pparent, listPointer check, int depth)
{
		while(check->right != check)
		{
			if(check->left == check && check->right == check)//only one child
			{
				//empty function
				empty_function(check, depth);//make emtpy space
				printf("━");
			}
			else if(check->left != check && check->right == check)//last child
			{
				//empty function
				empty_function(check, depth);
				printf("┗");
			}
			else if(check->left == check && check->right != check)//first child
			{
				printf("━━━━━━━━━━━");//vlftn
				printf("┳");
			}
			else if(check->left != check && check->right != check)//other child
			{
				//empty function
				empty_function(check, depth);
				printf("┣");
			}

			printf("%s", check->info.name);
			if(check->child != NULL)
			{
				int temp = depth;
				tree_traveling(pparent, check->child, ++temp);
			}

				check = check->right;
		}

		//empty function
		if(check->left == check && check->right == check)
		{
			printf("━━━━━━━━━━━");//vlftn
			printf("━");
			printf("%s", check->info.name);//vlftn
		}
		else if(check->left != check && check->right == check)
		{
			//empty function
			empty_function(check, depth);
			printf("┗%s",check->info.name);
			if(check->child != NULL)
			{
				int temp = depth;
				tree_traveling(pparent, check->child, ++temp);
			}

		}

}

void empty_function(listPointer check, int depth)
{
	listPointer parent = check;
	unsigned int parent_length[BUFFER_SIZE] = {0};
	int count = 0;

	printf("\n ");
	for(;parent->parent != NULL; count++)// get parents string length
	{
		parent_length[count] = strlen(parent->parent->info.name);
		parent = parent->parent;
	}

	int i = 1;

	for(;count > 0 ; count--)
	{
		for(int j = parent_length[count-1]; j > 0; j--)
			printf(" ");
	
		i++;
		printf("           ");
	
		if(i > 1 && i <= depth)//function connect line
			printf("┃");
	}

}
