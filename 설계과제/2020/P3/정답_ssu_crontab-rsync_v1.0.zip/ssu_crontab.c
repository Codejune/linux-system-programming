#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include "ssu_cron.h"

struct ssu_list front;

void ssu_crontab_prompt();
void ssu_crontab_showlist();
void init_list();
int isCycleOK(char * opt);
char* cmdToString(char* buf, struct ssu_cmd *cmd);
void usage();

int main(){
	char buf[BUFFER_SIZE];
	char cmdString[BUFFER_SIZE];
	init_list();
	while(1){
		memset(buf,0,BUFFER_SIZE);
		ssu_crontab_prompt();//프롬프트 출력
		fgets(buf,BUFFER_SIZE,stdin);//사용자 입력 대기

		//사용자 입력 파싱
		char *pcmd, *opt;
		int i=0;
		while(1){
			if(buf[i] == ' ' || buf[i] == '\n' || buf[i] == '\0'){
				buf[i] = '\0';
				pcmd = buf;
				opt = &buf[i+1];
				break;
			}
			else
				i++;
		}
		//add 명령어 수행
		if(strcmp(pcmd,"add") == 0){
			if(!(i=isCycleOK(opt))){//주기 검사, 뒤에나오는 명령어 및 명령어 옵션은 확인하지 않음
				usage();
				continue;
			}

			struct ssu_cmd *cmd;
			struct ssu_list *tmp;
			FILE *fp;
		
			tmp = malloc(sizeof(struct ssu_list));
			cmd = malloc(sizeof(struct ssu_cmd));

			strcpy(cmd->cycle,opt);
			strcpy(cmd->cmd_string,&opt[i]);
			tmp->object = cmd;
			tmp->next = NULL;

			struct ssu_list *end = &front;//리스트의 끝에 읽어들인 명령어 추가
			while(end->next){
				end = end->next;
			}
			end->next = tmp;

			//로그기록
			writeLog(SSU_CRONTAB_LOG,"add",cmdToString(cmdString,cmd));

			if(hasFile(SSU_CRONTAB_FILE) == 0){
				if(creatFile(SSU_CRONTAB_FILE) == 0){
					fprintf(stderr, "file create error\n");
					exit(1);			
				}
			}
			if((fp = fopen(SSU_CRONTAB_FILE,"w")) == NULL){
				fprintf(stderr, "fopen error\n");
				exit(1);
			}

			tmp = &front;
			while(tmp->next){
				fprintf(fp,"%s %s",((struct ssu_cmd*)(tmp->next->object))->cycle,((struct ssu_cmd*)(tmp->next->object))->cmd_string);
				tmp = tmp->next;
			}
			fclose(fp);
		}
		//remove 명령어 수행
		else if(strcmp(pcmd,"remove") == 0){
			i=0;
			int n=0;
			FILE *fp;

			if(opt[0] == 0){
				usage();
				continue;
			}
			if(isdigit(opt[0]) == 0){
				usage();
				continue;
			}
			while(isdigit(opt[i])){//입력된 숫자 확인
				n *= 10;
				n += opt[i++]-'0';
			}

			if(opt[i] != 0 && opt[i] != 10){//라인피드나 널이아니면 오류
				usage();
				continue;
			}
			struct ssu_list *tmp = &front;
			struct ssu_list *tmpbefore = NULL;
			do{
				tmpbefore = tmp;
				tmp = tmp->next;
			} while(n-- && tmp);
			if(!tmp){
				usage();
				continue;
			}
			tmpbefore->next = tmp->next;

			//로그기록
			writeLog(SSU_CRONTAB_LOG,"remove",cmdToString(cmdString,(struct ssu_cmd*)(tmp->object)));
			free(tmp->object);
			free(tmp);

			if(hasFile(SSU_CRONTAB_FILE) == 0){
				if(creatFile(SSU_CRONTAB_FILE) == 0){
					usage();
					exit(1);			
				}
			}
			if((fp = fopen(SSU_CRONTAB_FILE,"w")) == NULL){
				fprintf(stderr, "fopen error\n");
				exit(1);
			}

			tmp = &front;
			while(tmp->next){
				fprintf(fp,"%s %s",((struct ssu_cmd*)(tmp->next->object))->cycle,((struct ssu_cmd*)(tmp->next->object))->cmd_string);
				tmp = tmp->next;
			}
			fclose(fp);
		}
		//exit 명령어 수행
		else if(strcmp(pcmd,"exit") == 0){
			break;
		}
		else{
			usage();
		}
	}
	exit(0);
}
void init_list(){//파일에서 명령어를 읽어 리스트를 초기화
	char buf[BUFFER_SIZE];
	FILE *fp;
	struct ssu_list *tmp;
	int spaceCnt;
	int i;
	if(hasFile(SSU_CRONTAB_FILE) == 0){//파일이 있는지 확인
		if(creatFile(SSU_CRONTAB_FILE) == 0){//없을경우 생성
			fprintf(stderr, "file create error\n");
			exit(1);			
		}
	}
	if((fp = fopen(SSU_CRONTAB_FILE,"r+")) == NULL){//크론탭 파일 오픈
		fprintf(stderr, "fopen error\n");
		exit(1);
	}
	front.next = NULL;//리스트 초기화
	front.object = NULL;
	while(fgets(buf,BUFFER_SIZE,fp) != NULL){//파일에서 한줄씩 읽어 명령어 구성
		struct ssu_cmd *cmd;
		
		tmp = malloc(sizeof(struct ssu_list));
		cmd = malloc(sizeof(struct ssu_cmd));
		spaceCnt = 0;
		for(i=0;i<BUFFER_SIZE;i++){//주기와 명령어부를 나누어 저장
			if(isSpace(buf[i])){
				spaceCnt++;
			}
			if(spaceCnt == 5){
				buf[i] = 0;
				break;
			}
		}
		strcpy(cmd->cycle,buf);
		strcpy(cmd->cmd_string,&buf[i+1]);
		tmp->object = cmd;
		tmp->next = NULL;

		struct ssu_list *end = &front;//리스트의 끝에 읽어들인 명령어 추가
		while(end->next){
			end = end->next;
		}
		end->next = tmp;
	}
	fclose(fp);
}
void ssu_crontab_showlist(){
	int i=0;
	struct ssu_list *tmp = &front;
	while(tmp->next){
		printf("%d. %s %s",i++,((struct ssu_cmd*)(tmp->next->object))->cycle,((struct ssu_cmd*)(tmp->next->object))->cmd_string);
		tmp = tmp->next;
	}
}
void ssu_crontab_prompt(){//프롬프트 출력
	ssu_crontab_showlist();//ssu_crontab_file에 저장된 명령어 출력
	printf("\n%d> ",STUDENTID);
}

int isCycleOK(char * opt){
	int spaceCnt;
	int rangeFlag;
	int dividFlag;
	int num;
	int i;
	int rangeMin[5] = {0,0,1,1,0};
	int rangeMax[5] = {59,23,31,12,6};
	/*
	주기 검사
	분 시 일 월 요일 순으로 체크
	분 시 일 월 요일 까지만 정상입력 되면 뒷부분은 생각하지 않음
	*/
	i=0;
	spaceCnt = 0;
	while(spaceCnt < 5){
		rangeFlag = 0;//플래그 초기화
		dividFlag = 0;

		//첫 글자 확인
		if(isWildCard(opt[i])){//첫 글자가 '*'인 경우
			i++;
			rangeFlag = 1;
		}
		else if(isdigit(opt[i])){//첫 글자가 숫자인 경우
			num = 0;
			while(isdigit(opt[i])){
				num = num*10 + opt[i++] - '0';
			}
			if(!(rangeMin[spaceCnt] <= num && rangeMax[spaceCnt] >= num)){//만들어진 숫자가 지정된 범위를 벗어난 경우
				return 0;
			}
		}
		else{//첫 글자가 '*' 이거나 숫자가 아니면 에러
			return 0;
		}

		while(1){
			if(isSpace(opt[i])){//다음 주기 계산
				i++;
				spaceCnt++;
				break;
			}
			else if(isConnector(opt[i])){//연결자가 나올경우 연결자에 따라 다른작업 수행				
				if(opt[i] == '-'){//연결자로 '-'가 나온경우 지금까지 확인한 것이 range가 아니어야함 또한 이후에 숫자가 나와야 함
					if(rangeFlag){//지금까지 확인한 것이 range인 경우 에러
						return 0;
					}
					i++;
					rangeFlag = 1;
					if(!isdigit(opt[i])){//나온 첫 글자가 숫자가 아니면 에러
						return 0;
					}
					num = 0;
					while(isdigit(opt[i])){
						num = num*10 + opt[i++] - '0';
					}
					if(!(rangeMin[spaceCnt] <= num && rangeMax[spaceCnt] >= num)){//만들어진 숫자가 지정된 범위를 벗어난 경우
						return 0;
					}
				}
				
				else if(opt[i] == '/'){
					i++;
					if(!rangeFlag || dividFlag){//이전에 등장한 내용이 range가 아닌경우 에러, '/'가 이전에 등장했으면 에러
						return 0;
					}
					if(!isdigit(opt[i])){//나온 첫 글자가 숫자가 아니면 에러
						return 0;
					}
					num = 0;
					while(isdigit(opt[i])){
						num = num*10 + opt[i++] - '0';
					}
					dividFlag = 1;
				}
				else if(opt[i] == ','){//연결자로 ','가 나온경우 첫 글자 확인과 동일한 작업 수행
					i++;
					rangeFlag = 0;//플래그 초기화
					dividFlag = 0;
					if(isWildCard(opt[i])){//첫 글자가 '*'인 경우
						i++;
						rangeFlag = 1;
					}
					else if(isdigit(opt[i])){//첫 글자가 숫자인 경우
						num = 0;
						while(isdigit(opt[i])){
							num = num*10 + opt[i++] - '0';
						}
						if(!(rangeMin[spaceCnt] <= num && rangeMax[spaceCnt] >= num)){//만들어진 숫자가 지정된 범위를 벗어난 경우
							return 0;
						}
					}
					else{//첫 글자가 '*' 이거나 숫자가 아니면 에러
						return 0;
					}
				}
			}
			else{//주기 완성 전 다른종류의 문자가 등장할 경우 에러
				return 0;
			}
		}
	}

	opt[i-1] = 0;
	if(opt[i] == 0){
		//주기 이후 아무것도 입력되지 않은 경우 에러
		return 0;
	}

	return i;
}
char* cmdToString(char* buf, struct ssu_cmd *cmd){
	strcpy(buf,cmd->cycle);
	strcat(buf," ");
	strcat(buf,cmd->cmd_string);

	return buf;
}
void usage(){
	fprintf(stderr,"usage: ssu_crontab\n");
	fprintf(stderr,"\t[add] : 주기적으로 실행할 명령어 추가\n");
	fprintf(stderr,"\t사용형태 : add 주기 명령어 및 명령어 옵션\n");
	fprintf(stderr,"\t주기 : 분 시 일 월 요일 \n");
	fprintf(stderr,"\t\t분 : 0-59, 시 : 0-23, 일 : 1-31, 월 : 1-12, 요일 : 0-6 의 범위를 가짐\n");
	fprintf(stderr,"\t\t'*', '-', ',', '/' 기호를 사용하여 주기를 설정\n");
	fprintf(stderr,"\t\t\t'*' : 해당 필드의 모든 값을 의미\n");
	fprintf(stderr,"\t\t\t'-' : '-'으로 연결된 값들 모두를 의미\n");
	fprintf(stderr,"\t\t\t',' : ','로 연결된 값들 모두를 의미\n");
	fprintf(stderr,"\t\t\t'/' : 앞에 나온 주기의 범위를 뒤에 나온 숫자만큼 건너 뛰는 것을 의미\n");
	fprintf(stderr,"\t\t\tex) 0 0,12 */2 * * -> 2일마다 0시 0분, 12시 0분에 작업수행\n");
	fprintf(stderr,"\t[remove] : 지정한 번호의 명령어 삭제\n");
	fprintf(stderr,"\t사용형태 : remove 명령어 번호\n");
	fprintf(stderr,"\t[exit] : ssu_crontab 프로그램 종료\n");
	fprintf(stderr,"\t사용형태 : exit\n");
}
