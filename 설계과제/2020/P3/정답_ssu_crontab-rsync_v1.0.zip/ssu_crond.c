#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <string.h>
#include <sys/wait.h>
#include <ctype.h>
#include "ssu_cron.h"


int ssu_daemon_init(){
	pid_t pid;
	int fd, maxfd;

	if((pid = fork()) < 0){
		fprintf(stderr,"fork error\n");
		exit(1);
	}else if(pid >0){
		exit(0);
	}

	setsid();

	signal(SIGTTIN,SIG_IGN);
	signal(SIGTTOU,SIG_IGN);
	signal(SIGTSTP,SIG_IGN);

	umask(0);
	chdir("/");

	maxfd = getdtablesize();
	for(fd=0;fd<maxfd;fd++)
		close(fd);

	fd = open("/dev/null",O_RDWR);
	dup(0);
	dup(0);

	return 1;
}

struct ssu_list front;

char* cmdToString(char* buf, struct ssu_cmd *cmd);

int is_modified();
void init_list();
void cycleStr2Bit(struct ssu_cmd* cmd);
void check_cmd(struct ssu_cmd* cmd);
void run_cmd(struct ssu_cmd *cmd);
void add_cmd_list();

char logPath[1024];
char cronPath[1024];

time_t mtime;//최근에 읽은 ssu_crontab_file 의 mtime;

int main(int argc, char* argv[]){
	struct ssu_list *tmp;

	strcpy(logPath,argv[0]);
	logPath[strlen(logPath)-9]=0;
	strcat(logPath,SSU_CRONTAB_LOG);
	strcpy(cronPath,argv[0]);
	cronPath[strlen(cronPath)-9]=0;
	strcat(cronPath,SSU_CRONTAB_FILE);

	if(ssu_daemon_init() < 0){//데몬 초기화
		fprintf(stderr,"ssu_daemon_init error \n");
		exit(0);
	}
	init_list();//명령어 리스트 초기화
	while(1){
		if(is_modified() > 0){//파일 수정여부 체크
			printf("modified \n");
			//파일에서 읽은 명령어를 현재 리스트와 비교
			//삭제된 명령어 제거 및 없는 명령어 추가
			add_cmd_list();
			tmp = front.next;
			while(tmp){			
				printf("%s %s\n",((struct ssu_cmd*)(tmp->object))->cycle,((struct ssu_cmd*)(tmp->object))->cmd_string);
				tmp = tmp->next;
			}
		}

		//커맨드 리스트를 순회하며 시간을 비교 실행되야할 명령어 실행
		tmp = front.next;
		while(tmp){			
			check_cmd((struct ssu_cmd*)(tmp->object));
			tmp = tmp->next;
		}
	}

	exit(0);
}

int is_modified(){
	struct stat statbuf;
	if(hasFile(cronPath) == 0){
		if(creatFile(cronPath) == 0){
			fprintf(stderr, "file create error\n");
			exit(1);			
		}
	}
	if(stat(cronPath,&statbuf) != -1){//exist
		if(statbuf.st_mtime != mtime){//file changed;
			mtime = statbuf.st_mtime;
			return 1;
		}
	}
	return 0;	
}

void init_list(){//파일에서 명령어를 읽어 리스트를 초기화
	char buf[BUFFER_SIZE];
	FILE *fp;

	struct ssu_list *tmp;
	struct stat statbuf;
	int spaceCnt;
	int i;
	if(hasFile(cronPath) == 0){//파일이 있는지 확인
		if(creatFile(cronPath) == 0){//없을경우 생성
			fprintf(stderr, "file create error\n");
			exit(1);			
		}
	}
	if(stat(cronPath,&statbuf) < 0){
		fprintf(stderr,"stat error\n");
		exit(1);		
	}
	mtime = statbuf.st_mtime;

	if((fp = fopen(cronPath,"r+")) == NULL){//크론탭 파일 오픈
		fprintf(stderr, "fopen error\n");
		exit(1);
	}
	front.next = NULL;//리스트 초기화
	front.object = NULL;
	while(fgets(buf,BUFFER_SIZE,fp) != NULL){//파일에서 한줄씩 읽어 명령어 구성
		struct ssu_cmd *cmd;
		
		tmp = malloc(sizeof(struct ssu_list));
		cmd = malloc(sizeof(struct ssu_cmd));
		cmd->last_check.tm_min = 0;
		cmd->last_check.tm_hour = 0;
		cmd->last_check.tm_mday = 0;
		cmd->last_check.tm_mon = 0;

		spaceCnt = 0;
		for(i=0;i<BUFFER_SIZE;i++){//주기와 명령어부를 나누어 저장
			if(isSpace(buf[i])){
				spaceCnt++;
			}
			if(spaceCnt == 5){
				buf[i] = 0;
				break;
			}
		}
		strcpy(cmd->cycle,buf);
		strcpy(cmd->cmd_string,&buf[i+1]);
		tmp->object = cmd;
		tmp->next = NULL;

		struct ssu_list *end = &front;//리스트의 끝에 읽어들인 명령어 추가
		while(end->next){
			end = end->next;
		}
		end->next = tmp;
				
		cycleStr2Bit(cmd);//문자열 형태의 주기를 비트마스킹된 형태로 변경
	}
	fclose(fp);
}

void add_cmd_list(){//파일에서 명령어를 읽어 리스트 구성 및 기존 리스트와 비교하여 없는 경우 추가
	char buf[BUFFER_SIZE];
	FILE *fp;
	struct ssu_list *cur;
	struct ssu_list *before;
	struct ssu_list *tmp;
	struct stat statbuf;
	int spaceCnt;
	int i;
	if(hasFile(cronPath) == 0){//파일이 있는지 확인 -> 삭제된 경우 대비
		if(creatFile(cronPath) == 0){//없을경우 생성
			fprintf(stderr, "file create error\n");
			exit(1);			
		}
	}
	if(stat(cronPath,&statbuf) < 0){
		fprintf(stderr,"stat error\n");
		exit(1);		
	}
	mtime = statbuf.st_mtime;

	if((fp = fopen(cronPath,"r+")) == NULL){//크론탭 파일 오픈
		fprintf(stderr, "fopen error\n");
		exit(1);
	}
	cur = front.next;
	before = &front;
	while(fgets(buf,BUFFER_SIZE,fp) != NULL){//파일에서 한줄씩 읽어 명령어 구성
		struct ssu_cmd *cmd;
		
		spaceCnt = 0;
		for(i=0;i<BUFFER_SIZE;i++){//주기와 명령어부를 나누어 저장
			if(isSpace(buf[i])){
				spaceCnt++;
			}
			if(spaceCnt == 5){
				buf[i] = 0;
				break;
			}
		}
		while(1){
			if(cur == NULL){//비교할 기존 명령어가 없어진 경우
				tmp = malloc(sizeof(struct ssu_list));//새로 할당
				cmd = malloc(sizeof(struct ssu_cmd));

				cmd->last_check.tm_min = 0;
				cmd->last_check.tm_hour = 0;
				cmd->last_check.tm_mday = 0;
				cmd->last_check.tm_mon = 0;

				strcpy(cmd->cycle,buf);
				strcpy(cmd->cmd_string,&buf[i+1]);
				tmp->object = cmd;
				tmp->next = NULL;
				
				before->next = tmp;//할당받은 내용 저장

				before = before->next;
				cur = before->next;
				
				cycleStr2Bit(cmd);//문자열 형태의 주기를 비트마스킹된 형태로 변경
				break;
			}
			//기존 명령어와 비교하여 같은 경우 다음 명령어 읽어옴
			else if(strcmp(buf,((struct ssu_cmd*)(cur->object))->cycle)==0 && strcmp(&buf[i+1],((struct ssu_cmd*)(cur->object))->cmd_string)==0){
				before = before->next;
				cur = cur->next;			
				break;
			}
			//기존 명령어와 다른 경우 해당 명령어 삭제
			else{
				before->next = cur->next;
				free(cur->object);
				free(cur);
				cur = before->next;
			}
		}
	}
	//파일의 끝까지 읽었는데 cur이 맨 끝(NULL)을 가리키지 않는 경우 뒷부분 전부 해제
	before->next = NULL;
	while(cur){
		tmp = cur;
		cur = cur->next;
		free(tmp->object);
		free(tmp);
	}

	fclose(fp);
}

void cycleStr2Bit(struct ssu_cmd* cmd){//주기는 ssu_crontab을 통해 입력되어 정상이라는 가정 하에 작업 수행
	int spaceCnt;
	int rangeFlag;
	int dividFlag;
	int num1, num2;
	int i,j;
	int rangeMin[5] = {0,0,1,1,0};
	int rangeMax[5] = {59,23,31,12,6};

	char* cycle = cmd->cycle;
	unsigned long long currentBit;
	unsigned long long oldBit;
	/*
	문자열 형태의 주기를 비트로 변환
	분 시 일 월 요일 순으로 체크
	*/
	i=0;
	spaceCnt = 0;
	while(spaceCnt < 5){
		rangeFlag = 0;//플래그 초기화
		dividFlag = 0;
		
		currentBit = 0;//비트 초기화
		oldBit = 0;
		//첫 글자 확인
		if(isWildCard(cycle[i])){//첫 글자가 '*'인 경우
			i++;
			rangeFlag = 1;

			for(j=rangeMin[spaceCnt];j<=rangeMax[spaceCnt];j++){
				currentBit |= (unsigned long long)1 << j;
			}
		}
		else if(isdigit(cycle[i])){//첫 글자가 숫자인 경우 한비트 체크
			num1 = 0;
			while(isdigit(cycle[i])){
				num1 = num1*10 + cycle[i++] - '0';
			}
			currentBit |= (unsigned long long)1 << num1;
		}

		while(1){
			if(isSpace(cycle[i])){//다음으로				
				i++;
				cmd->cycleBit[spaceCnt++] = oldBit | currentBit;
				break;
			}
			else if(isConnector(cycle[i])){//연결자가 나올경우 연결자에 따라 다른작업 수행
				if(cycle[i] == '-'){//연결자로 '-'가 나온경우 num1 ~ num2 까지 의 비트 1로 변경
					i++;
					rangeFlag = 1;
					num2 = 0;
					while(isdigit(cycle[i])){
						num2 = num2*10 + cycle[i++] - '0';
					}
					int min, max;
					if(num1 > num2){
						max = num1;
						min = num2;
					}
					else{
						max = num2;
						min = num1;
					}
					//min ~ max 까지 비트 체크
					for(j=min;j<=max;j++){
						currentBit |= (unsigned long long)1 << j;
					}
				}
				else if(cycle[i] == '/'){//연결자로 '/'가 나온경우 건너뛰는 비트 0으로 변경
					i++;
					
					if(!rangeFlag || dividFlag){
						return;
					}
					num1 = 0;
					while(isdigit(cycle[i])){
						num1 = num1*10 + cycle[i++] - '0';
					}
					dividFlag = 1;

					int cnt=0;
					for(j=rangeMin[spaceCnt];j<=rangeMax[spaceCnt];j++){
						if(currentBit & ((unsigned long long)1 << j)){
							cnt++;
							if(cnt%num1){
								currentBit ^= (unsigned long long)1 << j;
							}
						}
					}
				}
				else if(cycle[i] == ','){//연결자로 ','가 나온경우
					i++;

					rangeFlag = 0;//플래그 초기화
					dividFlag = 0;

					oldBit |= currentBit; //oldBit 갱신
					currentBit = 0; //currentBit 초기화
					if(isWildCard(cycle[i])){//첫 글자가 '*'인 경우
						i++;
						rangeFlag = 1;
						for(j=rangeMin[spaceCnt];j<=rangeMax[spaceCnt];j++){
							currentBit |= (unsigned long long)1 << j;
						}
					}
					else if(isdigit(cycle[i])){//첫 글자가 숫자인 경우 한비트 체크
						num1 = 0;
						while(isdigit(cycle[i])){
							num1 = num1*10 + cycle[i++] - '0';
						}
						currentBit |= (unsigned long long)1 << num1;
					}
				}
				else{//cycle의 끝을 만난 경우
					spaceCnt++;
					break;
				}
			}
			else{
				cmd->cycleBit[spaceCnt++] = oldBit | currentBit;
				break;
			}
		}
	}
}
void check_cmd(struct ssu_cmd* cmd){//실행할 지 체크
	//현재시각 받아오기
	time_t now;
	struct tm *tm_now;
	struct tm *last_check;
	int run = 1;
	int i;

	time(&now);
	tm_now = localtime(&now);
	last_check = &(cmd->last_check);

	//최근 검사 시각과 비교
	if( last_check->tm_mon == tm_now->tm_mon && last_check->tm_mday == tm_now->tm_mday && last_check->tm_hour == tm_now->tm_hour && last_check->tm_min == tm_now->tm_min){
		return;
	}

	//현재시각과 기록해둔 비트마스킹과 검사
	if(!(cmd->cycleBit[4] & ((unsigned long long)1 << tm_now->tm_wday))){ //요일
		run = 0;
	}
	if(!(cmd->cycleBit[3] & ((unsigned long long)1 << tm_now->tm_mon+1))){ //월
		run = 0;
	}
	if(!(cmd->cycleBit[2] & ((unsigned long long)1 << tm_now->tm_mday))){ //일
		run = 0;
	}
	if(!(cmd->cycleBit[1] & ((unsigned long long)1 << tm_now->tm_hour))){ //시간
		run = 0;
	}
	if(!(cmd->cycleBit[0] & ((unsigned long long)1 << tm_now->tm_min))){ //분
		run = 0;
	}
	//최근 검사시간 갱신	
	last_check->tm_mon = tm_now->tm_mon;
	last_check->tm_mday = tm_now->tm_mday;
	last_check->tm_hour = tm_now->tm_hour;
	last_check->tm_min = tm_now->tm_min;
	if(run){
		run_cmd(cmd); //명령어 실행
	}
}

void run_cmd(struct ssu_cmd *cmd){
	int sys_ret=0;
	
	pid_t pid;
	char tmp_cmd[256];
	int status;

	if((pid = fork()) <0){
		fprintf(stderr,"fork error\n");
		return;
	}else if(pid > 0){
		wait(&status);
		return;
	}
	
	if((pid = fork()) <0){//double fork
		fprintf(stderr,"fork error\n");
		exit(1);
	}else if(pid > 0){
		exit(0);
	}
	sys_ret = system(cmd->cmd_string);
	char cmdString[BUFFER_SIZE];
	//명령어 실행 후 현재시각 및 해당 명령어를 로그에 기록
	//system의 리턴값을 통해 비정상 수행된 경우 제외
	if(!(WEXITSTATUS(sys_ret) == 127 || WEXITSTATUS(sys_ret) == -1))
		writeLog(logPath,"run",cmdToString(cmdString,cmd));
	exit(0);
	
}
char* cmdToString(char* buf, struct ssu_cmd *cmd){
	strcpy(buf,cmd->cycle);
	strcat(buf," ");
	strcat(buf,cmd->cmd_string);

	return buf;
}
