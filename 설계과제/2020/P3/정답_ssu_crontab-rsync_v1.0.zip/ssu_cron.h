#ifndef __SSU_CRON_H_
#define __SSU_CRON_H_

#include <time.h>

#define STUDENTID 20200000
#define SSU_CRONTAB_FILE "ssu_crontab_file"
#define SSU_CRONTAB_LOG "ssu_crontab_log"
#define BUFFER_SIZE 1024

struct ssu_list {
	struct ssu_list* next;
	void *object;
};

struct ssu_cmd{
	//주기
	char cycle[BUFFER_SIZE];
	//명령어
	char cmd_string[BUFFER_SIZE];
	//주기 비트마스킹
	//분 시 일 월 요일 (day of week)
	//0  1  2  3  4
	unsigned long long cycleBit[5];
	//최근 검사 시각, 분 시 일 월 만 사용
	struct tm last_check;
};

int hasFile(char* filename);
int creatFile(char* filename);
int isSpace(char c);//' ', '\t' 확인 
int isWildCard(char c);//'*' 확인
int isConnector(char c);//'-', ',', '/' 확인
void writeLog(char* logPath, char* tag, char* cmd);//로그 작성

#endif
