#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include <errno.h>
#include <utime.h>
#include <signal.h>
#include <unistd.h>
#include <ctype.h>
#include <time.h>

#define BUFFER_SIZE 1024

struct ssu_list {
	struct ssu_list* next;
	void *object;
};

struct ssu_list cp_list;// 동기화 시 카피할 파일 리스트
struct ssu_list rm_list;// -m 옵션 시 삭제할 파일 리스트

char *srcglo = NULL, *destglo = NULL;

int mirror = 0;
int recursive = 0;
int tar = 0;
off_t tarSize = 0;
int sigint_flag = 0;
char *tempdir;

void usage();
void check_opt(int argc, char* argv[]);
void make_cp_list(char* src, char* dest);
void make_rm_list(char* src, char* dest);
void copyfile(char* filename, char* tmpdir);
void signal_handler(int signo);
void remove_dir(char* dirname);
void writeLog(int argc, char* argv[]);

int main(int argc, char* argv[]) {	
	if(argc < 3){
		usage();
		exit(1);
	}
	
	check_opt(argc,argv);
	if(srcglo == NULL || destglo == NULL){
		usage();
		exit(1);
	}
	signal(SIGINT, signal_handler);//SIGINT 발생시 signal_handler의 동작을 수행
	make_cp_list("","");//카피할 파일 리스트 생성
	if(mirror){
		make_rm_list("","");//삭제할 파일 리스트 생성
	}

	
	tempdir = tempnam(destglo,NULL);//임시 디렉토리 생성
	if(mkdir(tempdir,0755) != 0){
		fprintf(stderr,"mkdir error %s\n",strerror(errno));
		exit(1);
	}

	if(tar){
		char olddir[BUFFER_SIZE];
		char cmd[BUFFER_SIZE] = "tar -rf tmp.tar";	
		
		getcwd(olddir,BUFFER_SIZE);

		chdir(srcglo);
		//카피할 파일들 tar
		struct ssu_list *tmp = &cp_list;
		while(tmp->next){
			strcat(cmd, " ");
			strcat(cmd,&((char *)(tmp->next->object))[1]);
			tmp = tmp->next;
		}
		system(cmd);
		//tar파일의 크기 확인
		struct stat statbuf;
		stat("tmp.tar",&statbuf);
		tarSize = statbuf.st_size;
		chdir(olddir);

		//tar 파일 카피
		copyfile("/tmp.tar",tempdir);

		//src 의 tar 파일 삭제
		chdir(srcglo);
		unlink("tmp.tar");
		chdir(olddir);

		//압축해제
		chdir(tempdir);
		strcpy(cmd,"tar -xvf tmp.tar");
		system(cmd);
		
		//tar 파일 삭제
		unlink("tmp.tar");
		chdir(olddir);
	}
	else{
		struct ssu_list *tmp = &cp_list;
		while(tmp->next){
			char filename[BUFFER_SIZE];
			struct stat statbuf;

			strcpy(filename,srcglo);
			strcat(filename,(char *)(tmp->next->object));

			stat(filename,&statbuf);

			if(S_ISREG(statbuf.st_mode)){
				copyfile((char *)(tmp->next->object),tempdir);
			}
			else if(S_ISDIR(statbuf.st_mode)){
				strcpy(filename,tempdir);
				strcat(filename,(char *)(tmp->next->object));
				mkdir(filename,0755);
			}
			
			tmp = tmp->next;
		}
	}
	signal(SIGINT, SIG_IGN);//카피 완료 후 SIG_INT 무시

	//기존파일 삭제 및 임시 디렉토리에서 파일 이동
	struct ssu_list *tmp = &cp_list;
	while(tmp->next){
		char olddst_filename[BUFFER_SIZE];
		char tmpdst_filename[BUFFER_SIZE];

		char filename[BUFFER_SIZE];
		struct stat statbuf;

		strcpy(filename,srcglo);
		strcat(filename,(char *)(tmp->next->object));
		stat(filename,&statbuf);

		if(S_ISDIR(statbuf.st_mode)){
			strcpy(filename,destglo);
			strcat(filename,(char *)(tmp->next->object));
			mkdir(filename,0755);
			
			tmp = tmp->next;
			continue;
		}

		strcpy(olddst_filename,destglo);
		strcat(olddst_filename,(char *)(tmp->next->object));
		unlink(olddst_filename); // 기존파일 삭제

		strcpy(tmpdst_filename,tempdir);
		strcat(tmpdst_filename,(char *)(tmp->next->object));
		link(tmpdst_filename,olddst_filename); //임시파일을 기존파일 이름으로 링크

		unlink(tmpdst_filename);//임시파일 삭제
		tmp = tmp->next;
	}
	if(mirror){
		//src에 없는 파일 dst에서 삭제		
		struct ssu_list *tmp = &rm_list;
		while(tmp->next){
			char rm_filename[BUFFER_SIZE];
			struct stat statbuf;

			strcpy(rm_filename,destglo);
			strcat(rm_filename,(char *)(tmp->next->object));
			
			stat(rm_filename,&statbuf);
			if(S_ISDIR(statbuf.st_mode)){//디렉토리인 경우 재귀적으로 내부 파일 삭제 후 디렉토리 삭제
				remove_dir(rm_filename);
			}
			else//일반파일인 경우 
				unlink(rm_filename);

			tmp = tmp->next;
		}
	}
	writeLog(argc,argv);//로그기록
	//임시 디렉토리 삭제
	remove_dir(tempdir);

	exit(0);
}

void usage(){
	fprintf(stderr,"usage: ssu_rsync [option] <src> <dest>\n");
	fprintf(stderr,"\t[option]\n");
	fprintf(stderr,"\t-r : 하위 디렉토리까지 동기화\n");
	fprintf(stderr,"\t-t : 동기화시 tar로 묶어서 동기화 수행\n");
	fprintf(stderr,"\t-m : src에 없는 파일이 dest에 존재할 경우 삭제\n");
}

void check_opt(int argc, char* argv[]){
	int i;
	struct stat statbuf;
	for(i=1;i<argc;i++){
		if(argv[i][0] == '-'){
			if(argv[i][1] == 'r'){
				recursive = 1;
			}
			else if(argv[i][1] == 't'){
				tar = 1;
			}
			else if(argv[i][1] == 'm'){
				mirror = 1;
			}
			else{
				usage();
				exit(1);
			}
		}
		else{
			if(srcglo == NULL){
				srcglo = malloc(BUFFER_SIZE);
				strcpy(srcglo,argv[i]);
			} else if(destglo == NULL){				
				destglo = malloc(BUFFER_SIZE);
				strcpy(destglo,argv[i]);

				stat(destglo, &statbuf);
				if(!S_ISDIR(statbuf.st_mode)){
					usage();
					exit(1);
				}
			}
		}	
	}
}

void make_cp_list(char* src, char* dest){
	char real_src[BUFFER_SIZE];
	char real_dst[BUFFER_SIZE];
	char tempdest[BUFFER_SIZE];
	char tempsrc[BUFFER_SIZE];

	struct stat srcstat, deststat;

	strcpy(real_src,srcglo);
	strcat(real_src,src);
	
	strcpy(real_dst,destglo);
	strcat(real_dst,dest);

	if(stat(real_src, &srcstat) < 0){
		usage();
		return;
	}
	if(S_ISDIR(srcstat.st_mode)){
		struct dirent *dirp;
		DIR *dp;
		

		dp = opendir(real_src);

		while((dirp = readdir(dp)) != NULL){ //src 디렉토리를 순회하며 dst 디렉토리에 없는 일반파일을 카피 리스트에 추가
			if(strcmp(dirp->d_name, ".") && strcmp(dirp->d_name, "..")){
				
				strcpy(tempdest,dest);
				strcat(tempdest,"/");
				strcat(tempdest,dirp->d_name);
				
				strcpy(real_dst,destglo);
				strcat(real_dst,tempdest);

				strcpy(tempsrc,src);
				strcat(tempsrc,"/");
				strcat(tempsrc,dirp->d_name); 

				strcpy(real_src,srcglo);
				strcat(real_src,tempsrc);

				stat(real_src, &srcstat);

				//카피대상이 디렉토리인 경우
				if(S_ISDIR(srcstat.st_mode)){// 카피하려는 파일이 디렉토리인 경우
					if(recursive){ // -r 옵션 체크
						struct ssu_list *tmp = malloc(sizeof(struct ssu_list));
						char *cpfile = malloc(BUFFER_SIZE);
						strcpy(cpfile,tempsrc);
						tmp->object = cpfile;
						tmp->next = NULL;
	
						struct ssu_list *end = &cp_list;//리스트의 끝에 동기화 대상 추가
						while(end->next){
							end = end->next;
						}
						end->next = tmp;
						make_cp_list(tempsrc,tempdest); // 재귀적으로 리스트 생성
					} else{ // 설정되지 않은경우 스킵
						continue;
					}
				}
				else if(S_ISREG(srcstat.st_mode)){ // 일반파일인 경우
					//dst에 대상의 존재여부 체크
					if(!access(real_dst, F_OK)){ // dst에 대상이 있는 경우
						// 파일 크기 및 수정시간 체크
						stat(real_dst, &deststat);
						if(srcstat.st_size == deststat.st_size && srcstat.st_mtime == deststat.st_mtime){ //같으면 스킵
							continue;	
						}
					}
					// dst에 대상이 없거나 파일 크기 및 수정시간이 다른경우 리스트에 항목 추가
					struct ssu_list *tmp = malloc(sizeof(struct ssu_list));
					char *cpfile = malloc(BUFFER_SIZE);
					strcpy(cpfile,tempsrc);
					tmp->object = cpfile;
					tmp->next = NULL;

					struct ssu_list *end = &cp_list;//리스트의 끝에 동기화 대상 추가
					while(end->next){
						end = end->next;
					}
					end->next = tmp;
				}
			}
		}
	} else{ //일반파일인 경우 경로와 파일 명을 분리
		int length = strlen(srcglo);
		char* filename;

		while(srcglo[length] != '/'){
			if(length-- == 0) break;
		}
		filename = &srcglo[length+1];

		strcpy(tempdest,destglo);
		strcat(tempdest,"/");
		strcat(tempdest,filename);

		if(access(tempdest, F_OK) == 0){
			stat(src, &srcstat);
			stat(tempdest, &deststat);

			if(srcstat.st_size == deststat.st_size && srcstat.st_mtime == deststat.st_mtime){
				return;
			}
		}
		struct ssu_list *tmp = malloc(sizeof(struct ssu_list));
		char *cpfile = malloc(BUFFER_SIZE);
		strcpy(cpfile,"/");
		strcat(cpfile,filename);
		tmp->object = cpfile;
		tmp->next = NULL;

		struct ssu_list *end = &cp_list;//리스트의 끝에 동기화 대상 추가
		while(end->next){
			end = end->next;
		}
		end->next = tmp;
		if(!mirror){
			srcglo[0] = '.';
			srcglo[1] = 0;
		}
	}
}
void make_rm_list(char* src, char* dest){
	char real_src[BUFFER_SIZE];
	char real_dst[BUFFER_SIZE];
	char tempdest[BUFFER_SIZE];
	char tempsrc[BUFFER_SIZE];

	struct stat srcstat, deststat;

	strcpy(real_src,srcglo);
	strcat(real_src,src);
	
	strcpy(real_dst,destglo);
	strcat(real_dst,dest);

	if(stat(real_src, &srcstat) < 0){
		fprintf(stderr,"In make_rm_list stat error for %s\n",src);
		return;
	}
	if(S_ISDIR(srcstat.st_mode)){
		struct dirent *dirp;
		DIR *dp;

		dp = opendir(real_dst);

		while((dirp = readdir(dp)) != NULL){ //dst 디렉토리를 순회하며 src 디렉토리에 없는 대상 삭제 리스트에 추가
			if(strcmp(dirp->d_name, ".") && strcmp(dirp->d_name, "..")){
				strcpy(tempdest,dest);
				strcat(tempdest,"/");
				strcat(tempdest,dirp->d_name);
				
				strcpy(real_dst,destglo);
				strcat(real_dst,tempdest);

				strcpy(tempsrc,src);
				strcat(tempsrc,"/");
				strcat(tempsrc,dirp->d_name); 

				strcpy(real_src,srcglo);
				strcat(real_src,tempsrc);

				stat(real_src, &srcstat);

				if(access(real_src, F_OK)){ // src에 대상이 없는 경우
					struct ssu_list *tmp = malloc(sizeof(struct ssu_list));
					char *rmfile = malloc(BUFFER_SIZE);
					strcpy(rmfile,tempsrc);
					tmp->object = rmfile;
					tmp->next = NULL;

					struct ssu_list *end = &rm_list;//리스트의 끝에 삭제할 대상 추가
					while(end->next){
						end = end->next;
					}
					end->next = tmp;
				}
			}
		}
	} else{ //일반파일인 경우
		int length = strlen(real_src);
		char* filename;
		struct dirent *dirp;
		DIR *dp;

		while(real_src[length] != '/'){//파일 명만 추출
			if(length-- == 0) break;
		}
		filename = &real_src[length+1];

		dp = opendir(real_dst);

		while((dirp = readdir(dp)) != NULL){ //dst 디렉토리를 순회하며 src와 같은이름의 파일을 제외하고 리스트에 추가
			if(strcmp(dirp->d_name, ".") && strcmp(dirp->d_name, "..")){
				if(strcmp(dirp->d_name,filename)==0){
					continue;
				}

				struct ssu_list *tmp = malloc(sizeof(struct ssu_list));
				char *rmfile = malloc(BUFFER_SIZE);

				strcpy(tempdest,dest);
				strcat(tempdest,"/");
				strcat(tempdest,dirp->d_name);

				strcpy(rmfile,tempdest);
				tmp->object = rmfile;
				tmp->next = NULL;

				struct ssu_list *end = &rm_list;//리스트의 끝에 삭제할 대상 추가
				while(end->next){
					end = end->next;
				}
				end->next = tmp;
			}
		}
		srcglo[0] = '.';
		srcglo[1] = 0;
	}
}
void copyfile(char* filename, char* tmpdir){
	char srcfile[BUFFER_SIZE];
	char destfile[BUFFER_SIZE];

	int srcfd, destfd;
	char *tempdest;
	char buf[BUFFER_SIZE];
	int length;
	struct utimbuf time_buf;
	struct stat statbuf;

	strcpy(srcfile,srcglo);
	strcat(srcfile,filename);

	strcpy(destfile,tmpdir);
	strcat(destfile,filename);

	stat(srcfile, &statbuf);
	time_buf.actime = statbuf.st_atime;
	time_buf.modtime = statbuf.st_mtime;
	
	if((destfd = open(destfile, O_WRONLY|O_CREAT, 0644)) < 0){
		fprintf(stderr,"In copyfile open error for destfile\n");
		return;
	}

	if((srcfd = open(srcfile, O_RDONLY)) < 0){
		fprintf(stderr,"In copyfile open error for %s\n",srcfile);
		return;
	}

	while(1){//파일 카피
		if((length = read(srcfd, &buf, sizeof(buf))) > 0){
			write(destfd, &buf, length);
		} else{
			break;
		}
	}
	
	close(srcfd);
	close(destfd);

	if(utime(destfile,&time_buf) < 0){//파일의 수정시간 변경
		fprintf(stderr,"In copyfile utime error\n");
		return;
	}
}

void remove_dir(char* dirname){
	struct dirent *dirp;
	DIR *dp;
	char filename[BUFFER_SIZE];
	struct stat statbuf;

	dp = opendir(dirname);
	while((dirp = readdir(dp)) != NULL){ //디렉토리를 순회하여 일반파일 및 디렉토리를 삭제
		if(strcmp(dirp->d_name, ".") && strcmp(dirp->d_name, "..")){
			strcpy(filename,dirname);
			strcat(filename,"/");
			strcat(filename,dirp->d_name);

			stat(filename,&statbuf);
			if(S_ISDIR(statbuf.st_mode)){//디렉토리인 경우 재귀적으로 삭제
				remove_dir(filename);
			}
			else{
				unlink(filename);
			}
		}
	}
	rmdir(dirname);
}

void writeLog(int argc, char* argv[]){
	char *logPath = "ssu_rsync_log";
	char buf[BUFFER_SIZE];
	time_t now;
	FILE *fp;
	int i;

	fp = fopen(logPath,"a+");
	time(&now);
	strcpy(buf,ctime(&now));
	buf[strlen(buf)-1]=0;
	
	fprintf(fp,"[%s] ssu_rsync",buf);
	for(i=1;i<argc;i++){
		fprintf(fp," %s",argv[i]);
	}
	fprintf(fp,"\n");

	if(tar){
		fprintf(fp,"\ttotalSize %ldbytes\n",tarSize);
	}
	struct ssu_list *tmp = &cp_list;
	while(tmp->next){
		char filename[BUFFER_SIZE];
		struct stat statbuf;

		strcpy(filename,srcglo);
		strcat(filename,(char *)(tmp->next->object));
		stat(filename,&statbuf);

		if(S_ISDIR(statbuf.st_mode)){//디렉토리는 로그에 기록하지 않음
			tmp = tmp->next;
			continue;
		}
		if(tar)
			fprintf(fp,"\t%s\n",&((char *)(tmp->next->object))[1]);
		else
			fprintf(fp,"\t%s %ldbytes\n",&((char *)(tmp->next->object))[1],statbuf.st_size);
		tmp = tmp->next;
	}
	if(mirror){
		struct ssu_list *tmp = &rm_list;
		while(tmp->next){
			char filename[BUFFER_SIZE];
			struct stat statbuf;

			strcpy(filename,srcglo);
			strcat(filename,(char *)(tmp->next->object));
			stat(filename,&statbuf);

			fprintf(fp,"\t%s delete\n",&((char *)(tmp->next->object))[1]);
			tmp = tmp->next;
		}
	}

	fclose(fp);
}

void signal_handler(int signo) {
	signal(SIGINT, SIG_IGN);//카피 완료 후 SIG_INT 무시
	remove_dir(tempdir);//임시디렉토리와 지금까지 카피한 파일들 삭제
	exit(0);//프로그램 종료
}
