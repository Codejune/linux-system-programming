#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include "ssu_cron.h"

int hasFile(char* filename){
	if(access(filename, F_OK)){
		return 0;
	}
	return 1;
}
int creatFile(char* filename){
	int fd;
	if((fd = open(filename, O_RDWR|O_CREAT, 0644)) < 0){
		fprintf(stderr,"file create error\n");
		return 0;
	}
	close(fd);
	return 1;
}
int isSpace(char c){
	if(c==' ' || c=='\t'){
		return 1;
	}
	return 0;
}
int isWildCard(char c){
	if(c=='*'){
		return 1;
	}
	return 0;
}
int isConnector(char c){
	if(c=='-' || c=='/' || c==','){
		return 1;
	}
	return 0;
}
void writeLog(char* logPath, char* tag, char* cmd){
	char buf[BUFFER_SIZE];
	time_t now;
	FILE *fp;

	fp = fopen(logPath,"a+");
	time(&now);
	strcpy(buf,ctime(&now));
	buf[strlen(buf)-1]=0;
	
	fprintf(fp,"[%s] %s %s",buf,tag,cmd);

	fclose(fp);
}
