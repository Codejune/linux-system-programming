C_SSU_Crontab&Rsync

#Requirement
1. Makefile 통합 생성
- https://jhb.kr/56?category=735240
- https://mug896.github.io/make-script/rules.html
2. Doxyzen 주석 규칙 적용
- https://github.com/xpressengine/xe-core/wiki/%EC%BD%94%EB%93%9C-%EB%AC%B8%EC%84%9C%ED%99%94%EB%A5%BC-%EC%9C%84%ED%95%9C-%EC%A3%BC%EC%84%9D-%EA%B7%9C%EC%B9%99(Draft-v0.1)
3. gdb 디버깅
- https://blankspace-dev.tistory.com/434?category=705047
4. MacOS systemctl
- https://devlog.jwgo.kr/2019/07/03/how-do-i-check-if-a-service-is-running-in-mac/
5. crontab 등록
- https://zetawiki.com/wiki/스크립트_crontab_등록
