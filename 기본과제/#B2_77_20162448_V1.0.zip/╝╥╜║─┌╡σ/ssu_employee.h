#define NAME_SIZE 64

struct ssu_employee {
	char name[NAME_SIZE];
	int pid;
	int salary;
};
